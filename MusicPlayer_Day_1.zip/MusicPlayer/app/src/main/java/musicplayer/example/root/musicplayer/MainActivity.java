package musicplayer.example.root.musicplayer;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity implements View.OnClickListener{

    // Define reference for the music player components

    ImageButton play, pause, fastforward, rewind;
    TextView songName, timetoend, timefromstart;
    SeekBar currentPosition;

    String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play = (ImageButton) findViewById(R.id.playimageButton);
        pause = (ImageButton) findViewById(R.id.pauseimageButton);
        fastforward = (ImageButton) findViewById(R.id.fastforwardimageButton);
        rewind = (ImageButton) findViewById(R.id.rewindimageButton);

        songName = (TextView) findViewById(R.id.songNametextView);
        timetoend = (TextView) findViewById(R.id.runtimetostoptextView);
        timefromstart = (TextView) findViewById(R.id.runtimefromstarttextView);

        currentPosition = (SeekBar) findViewById(R.id.seekBar);


        play.setOnClickListener(this);
        pause.setOnClickListener(this);
        fastforward.setOnClickListener(this);
        rewind.setOnClickListener(this);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.playimageButton: {

                Log.i(TAG,"Play Button Clicked");

                // Resources res = getResources();
                // Drawable img = res.getDrawable(android.R.drawable.ic_media_ff, getApplicationContext().getTheme());

                play.setImageResource(android.R.drawable.ic_media_play);
                pause.setImageResource(R.drawable.pause);
                fastforward.setImageResource(R.drawable.fastforward);
                rewind.setImageResource(R.drawable.rewind);

                break;
            }

            case R.id.pauseimageButton:{

                Log.i(TAG, "Pause Button Clicked");

                play.setImageResource(R.drawable.play);
                pause.setImageResource(android.R.drawable.ic_media_pause);
                fastforward.setImageResource(R.drawable.fastforward);
                rewind.setImageResource(R.drawable.rewind);

                break;
            }

            case R.id.fastforwardimageButton:{

                Log.i(TAG, "Fast Forward Button Clicked");

                play.setImageResource(R.drawable.play);
                pause.setImageResource(R.drawable.pause);
                fastforward.setImageResource(android.R.drawable.ic_media_ff);
                rewind.setImageResource(R.drawable.rewind);

                break;
            }

            case R.id.rewindimageButton:{

                Log.i(TAG, "Rewind Button Clicked");

                play.setImageResource(R.drawable.play);
                pause.setImageResource(R.drawable.pause);
                fastforward.setImageResource(R.drawable.fastforward);
                rewind.setImageResource(android.R.drawable.ic_media_rew);

                break;
            }


        }


    }
}
